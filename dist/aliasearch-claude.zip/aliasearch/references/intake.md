# Intake and prompt fidelity

Read the full prompt, prior answers, attachments, and available business materials before asking anything. User instructions outrank workflow defaults. Expertise should improve execution, never silently change the requested job.

If the user provides a website or catalogue, read relevant offer, use-case, geography and customer pages first. Extract only supported facts with source links; ask the user about material gaps or contradictions. A website is optional: a plain-language description works. Never treat marketing claims, competitor pages or illustrative examples as verified purchasing requirements.

When buyer segments are genuinely unspecified, propose a small set of plausible segments with a reason and the evidence needed to qualify each. Label these as hypotheses, not customers or numerical probabilities. Preserve any segments the user already specified; ask before narrowing or replacing them. Use the user's examples and exclusions to refine the search.

## Request contract

Track these internally. Mark each `specified`, `missing`, or `conflicting`:

- outcome and intended audience
- offer/use case, target type (organization, buyer, end user, partner, or other), and relevant role
- geography and requested count
- include/exclude rules and examples
- evidence or qualification threshold
- required platforms and contact routes
- output format, columns, and level of detail
- outreach goal, approved claims, sender, language, and copy constraints
- commercial or operational limits
- actions explicitly authorized or prohibited

Use supplied details as fixed inputs. Preserve exact counts, markets, channels, exclusions, requested format, and negative instructions. Never substitute a smaller sample, different platform, preferred template, or extra output without asking. If the task cannot be completed as written, state the concrete limit and ask which scope change the user accepts.

## Questions

Ask about every missing fact that could materially change targeting, qualification, research scope, contact choice, or requested copy. There is no fixed question limit. Group concise questions in one turn, ordered by decision impact. Explain the choice only when the reason is not obvious. Use simple options when they reduce effort.

Do not ask for facts already supplied, publicly researchable facts, or preferences that do not affect the result. Do not send a long intake form by default. First extract answers; then ask only remaining gaps. Ask research-critical questions before dependent research. Ask copy-only questions when drafting becomes the next task. If later questions depend on sector knowledge, map the sector first, then ask a focused second set.

Treat unknowns as follows:

- **Material and unresolved:** pause dependent decisions; ask. Continue only independent work.
- **Conflicting:** show the conflicting values and source; ask which controls.
- **Low impact:** choose a conventional default, label it as a default, and keep moving.
- **User says no assumptions:** do not infer a material fact. Ask or mark that part blocked; never hide the gap.

Do not make the user approve a paraphrase of a clear request. Confirm only a disputed interpretation or a change that affects scope. After answers, update the internal contract, do not repeat questions, and execute the full requested scope.

## Useful question areas

Ask only where relevant:

1. What is offered, what does it replace or enable, and which use cases/specifications decide fit?
2. Which target types matter (organizations, named buyers, end users, partners)? What good/bad examples or use signals exist?
3. Which locations, count, languages, and channels are in scope?
4. What makes a lead qualified: required product evidence, scale, budget, purchasing role, service area, or public contact route?
5. Which firms/people/aliases are excluded? What commercial or operational limits apply?
6. Which differentiators, references, proof, sender details, reply goal, and approved copy can outreach use?
7. What exact deliverable is wanted: file type, fields, depth, message channel, and whether drafts only or any external action?

For product research, build the sector map from public information; do not make the user supply industry terminology or search sources. Ask only when the market has distinct buyer interpretations that change who qualifies.

## Conditional trade questions

Use these only for physical goods when cross-border importer/exporter evidence could materially improve discovery. Do not add them to service, software, individual-user, local-only, or unrelated research.

- Ask whether the user already knows an HS, HSN, HTS, CN, or national tariff code. A code is optional.
- If no code is supplied, infer candidate code families from the product description and public classification sources. Ask only for missing characteristics that change classification, such as material or composition, physical form, construction or manufacturing method, end use, weight or dimensions, finish, packaging, and destination jurisdiction.
- Ask import versus export direction, origin, destination, and relevant time range only when they change the trade-data query.
- Never make the user find a code before research can begin. Label inferred codes as candidates until verified against the current tariff for the relevant jurisdiction.
- Do not ask for trade details merely because the offer is a physical product. Use this branch when trade flows or shipment records are likely to improve market selection or company discovery.

Keep the request contract concise and internal. Do not paste it into every lead row. At delivery, follow requested output first; put additional recommendations separately and only when useful.
