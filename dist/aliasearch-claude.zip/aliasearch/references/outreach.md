# Outreach and output

## Draft standard

Write as a credible peer, not a vendor template. Lead with the prospect's business context when a verified hook exists; otherwise use a relevant segment-level opening. Introduce sender naturally after relevance is established. Every sentence must help recognition, credibility, offer fit, or reply. If a reference message is supplied, preserve its structure, claims, order and tone unless the user approves a change.

Personalization must connect a verified fact to the reason for outreach. Use facts such as product range, market served, role, recent business activity, hiring, event participation, or a public statement only when current and source-backed. Never manufacture a hook. Avoid generic praise, personal trivia, scraped-sounding language, guessed buyer names, invented intent, stale congratulations, or telling recipients how they were researched.

Use one primary offer angle, one proof point when approved, and one low-friction reply ask. Do not dump every feature or product. A first email should usually be short enough to read on a phone; length may expand when the user supplies an approved longer format or the offer genuinely requires detail. Read it aloud: remove marketing jargon, repetition, robotic transitions, fake familiarity, and AI patterns such as “I hope this email finds you well,” “I came across your profile,” “leverage,” “synergy,” contrast slogans, self-answered questions, and em dashes.

Email subject: usually 2–4 plain words, specific to context or problem, lowercase when natural. Avoid recipient first name, urgency, emojis, percentages, sales claims, fake `Re:`/`Fwd:`, or product pitches. Use one normal greeting, a context-to-offer bridge, approved sender identity/proof, one or two matched items, and one calm invitation to reply. Do not ask for a long meeting in first touch. No attachment, image, or multiple-link suggestion unless user requests it.

Choose shape from evidence, not habit:

- verified observation, relevant implication, offer bridge, soft reply ask;
- targeted question, concise value, proof, soft reply ask;
- trigger, useful insight, offer bridge, soft reply ask;
- similar-customer problem, approved proof, relevance question.

Social DM: shorter and conversational; mention discovery platform naturally at most once; include exact profile link in contact view, not message unless useful. Call brief: company activity, fit, offer angle, evidence, number provenance, likely buyer desk, and opening question. For `explore`, ask whether relevant sourcing or need is handled there; never assert proven fit.

If follow-ups are requested, prepare up to four. Each must stand alone and add one new useful angle, proof point, insight, or resource. Never write “just checking in,” guilt the recipient, or repeat the first email. Final follow-up closes the loop respectfully. Stop-sequence and reply handling remain outside Aliasearch unless separately requested and authorized.

Default user-facing columns: `Company`, `Location`, `Contact`, `Why this fits`, `Message`. Include `Subject` only for email and a clickable company or profile link only when useful. Put phone and email in Contact without repeating them elsewhere. Add fields only when needed for action. Keep held leads and internal gate details out of the default workbook; provide exploratory leads separately only if requested. For Excel, use a frozen header, filters, legible widths, wrapped text, accessible contrast, and functional links; verify the workbook opens and content is readable. If Excel creation fails, provide CSV and explain the fallback. Internal ledger retains source links, dates and decisions.

Before delivery, check: verified hook or honest segment opening; relevance survives removal of company name; sender claims approved; one clear offer angle; one low-friction ask; no invented facts; human voice; route sourced. Measure human reply, qualified reply, sample/meeting, quote, and order separately. Do not infer deliverability or promise a conversion rate. Sending, domain setup, tracking, sequences, and inbox integration require separate authorization.
