# Research and records

Use sources available to the current assistant. Check access once. Never require users to install a named tool. For a source family, log query, URL, date, names found, unique firms, qualified firms, and access state.

Use relevant source layers: fairs, associations, registries, procurement portals and sector directories; business directories and marketplaces; company-owned sites; and public social profiles. Respect explicitly requested platforms. Deduplicate names before deep research. Verify promising names on company-owned sites or clearly attributable business profiles. A business's own social profile can establish a directly shown product or service when identity and context are clear; a snippet, generic post or follower count alone cannot establish purchasing fit. Inactive profiles are neutral. Do not claim broad social coverage from snippets.

Use the requested count; suggest 20 if none was given. Select source layers appropriate to the sector and access available. For manufacturers, prioritize trade fairs and wholesale directories; for local services, business listings and associations; for software, company sites and relevant industry directories. Verify each candidate independently. Keep candidates in the ledger, rank by evidence and fit, and return only qualified results. If fewer pass, identify the missing proof.

Canonical records: company ID and aliases; source ID, URL and checked date; one observation per claim with source ID; public contact and source ID; decision with missing gate; draft with source ID. Keep raw excerpts out of contact export.

After a company passes fit checks, search for a relevant purchasing or decision-making role when the user needs a person. Record the person's role, source, date, and whether the contact route is directly published for that person or is a shared company inbox. Do not infer that a founder is the buyer or manufacture an email address. If no named person is verified, use a sourced business route or hold the lead according to the brief.

Track discovery yield by source and segment: candidates found, unique firms, qualified firms and usable contact routes. Compare these counts before spending more effort; retain requested sources even when yield is low. A source listing or model score is a discovery signal, not proof of buyer fit or current intent.

Four contact-now gates: identity/target market, acceptable buying role, specific offer/use match, public business route. Label fit exact, family, or needs confirmation. A directory/fair listing alone never passes all gates. `Explore` requires identity, route, plausible relevance, and explicit approval for lower-confidence outreach; keep separate. Missing evidence is held, not guessed. Clear mismatch, existing customer, and duplicate are excluded.

For each candidate send AI only decisive excerpts, offer constraints, contact candidates, and source IDs. Reject a positive decision whose citation does not exist. Revisit only when source, brief, or a missing gate changes. Parallel agents own disjoint query slices and append through one import queue.
